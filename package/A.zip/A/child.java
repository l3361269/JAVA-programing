package A;

import javax.sound.midi.Instrument;

class child {
	public String name="son";
	int age =15;
	private int money=500; //private�u��Φb�ۤvclass

}
