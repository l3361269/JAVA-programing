package A;

public class mother {
	public String name="Ma";
	int age=45;
	private int money=20000;//private�u��Φb�ۤvclass

}
